create function regexp_matches(citext, citext) returns SETOF text[]
    immutable
    strict
    parallel safe
    rows 1
    language sql
as
$$
    SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter function regexp_matches(citext, citext) owner to postgres;

